<?php
// Hardcoded admin credentials
$username = "admin";
$password = "admin";

// Connect to database
$mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');

if ($mysqli->connect_errno){
  echo "Error: Problème de connexion à la BDD<br>";
  exit();
}

$mysqli->set_charset("utf8");

// Hash the password
$hashed_password = hash('sha256', $password);

// Insert admin
$sql = "INSERT INTO t_admin_adm (adm_username, adm_password) VALUES ('$username', '$hashed_password');";

if ($mysqli->query($sql)) {
    echo "Admin créé avec succès !<br>";
} else {
    echo "Erreur: " . $mysqli->error;
}

$mysqli->close();
?>