<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Système de Gestion Solaire - Administration</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: url('https://images.unsplash.com/photo-1628953535333-a64a918181c0?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDEwfHx8ZW58MHx8fHx8&ixlib=rb-4.1.0&q=60&w=3000') center/cover no-repeat;
      min-height: 100vh;
      padding: 20px;
      display: flex;
      align-items: center;
      flex-direction: column;
      justify-content: center;
    }

    #header {
      width: 98%;
      height: auto;
      order: 1;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      border-radius: 2cap;
    }

    #navigation {
      width: 90%;
      height: auto;
      order: 2;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #contenu {
      width: 90%;
      height: auto;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      order: 3;
      background-color: #69e2ff;
      color: #495057;
      padding: 5%;
      text-align: center;
      margin-top: 1%;
      border-radius: 2cap;
      overflow-x: auto;
    }

    #footer {
      width: 98%;
      height: auto;
      order: 4;
      background-color: rgb(187, 241, 187);
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      color: #495057;
      text-align: center;
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    form p {
      margin: 15px 0;
    }

    form input, form button {
      padding: 6px;
      margin-top: 5px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      table-layout: auto;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: left;
      word-wrap: break-word;
    }

    th {
      background-color: #e0f7fa;
      font-weight: bold;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    h3, h1 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}
 strong {
  color: #222;
}

 hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}

    #navigation a {
  color: #495057;
  text-decoration: none;
  padding: 8px 12px;
  margin: 5px;
  display: inline-block;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 5px;
}

#navigation a:hover {
  background-color: rgba(255, 255, 255, 0.6);
}
#navigation a.active {
  background-color: rgba(0, 128, 0, 0.6); 
  color: white; 
}
#contenu h3 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


#contenu p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

#contenu ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}

#contenu strong {
  color: #222;
}

#contenu hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}


    </style>
</head>

<body>

<div id="header">
  <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc()) {
        echo '<h1 style="display:flex; align-items:center; gap:10px; justify-content:center;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
            <b>'.$info['cfg_name'].'</b>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
        </h1>';
    }
    }
    
    $mysqli->close();
    ?>
    <p>Plateforme complète pour la gestion et le suivi de vos installations photovoltaïques</p>
  </div>



  <div id="navigation">
  <p>
  <a href="index.php">Présentation</a> 
  <a href="extraire.php">Extraire</a>
  <a href="installations.php">Installations</a> 
  <a href="ajout_installation.php">Ajouter installation</a> 
  <a href="join.php">Nous rejoindre</a>
</p>
  </div>

  <div id="contenu">
    <h3>Gestion des Demandes</h3>

    <form action="admin_action.php" method="post">
      <p>Nom d'utilisateur: <input type="text" name="admin_username" required></p>
      <p>Mot de passe: <input type="password" name="admin_password" required></p>
      <p><input type="submit" value="Se connecter"></p>
    </form>

    <?php
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }

    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }

    mysqli_report(MYSQLI_REPORT_OFF);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_username']) && isset($_POST['admin_password'])) {
        $admin_username = htmlspecialchars(addslashes($_POST['admin_username']));
        $admin_password = htmlspecialchars(addslashes($_POST['admin_password']));

        if (empty($admin_username) || empty($admin_password)) {
            echo 'Veuillez remplir les formulaires !!!';
        }
        else {
        $sql = "SELECT adm_id, adm_username, adm_password FROM t_admin_adm WHERE adm_username = '$admin_username';";
        $result = $mysqli->query($sql);

        if ($result == false) {
            echo "Error: La requête a échoué<br>";
            echo "Query: " . $sql . "<br>";
            echo "Errno: " . $mysqli->errno . "<br>";
            echo "Error: " . $mysqli->error . "<br>";
            exit();
        }

        $authOK = false;

        while ($info = $result->fetch_assoc()) {
            if ($info['adm_password'] == hash('sha256', $admin_password)) {
                $authOK = true;

                // Handle approve action
                if (isset($_POST['approve'])) {
                    $dmd_id = $_POST['dmd_id'];
                    
                    $sql2 = "SELECT * FROM t_demandes_dmd WHERE dmd_id = $dmd_id;";
                    $result2 = $mysqli->query($sql2);
                    
                    if ($result2 == false) {
                        echo "Error: La requête a échoué<br>";
                        echo "Query: " . $sql2 . "<br>";
                        echo "Errno: " . $mysqli->errno . "<br>";
                        echo "Error: " . $mysqli->error . "<br>";
                        exit();
                    }
                    
                    if ($demande = $result2->fetch_assoc()) {
                        // $generatedPassword = bin2hex(random_bytes(8));
                        
                        $mmb_name = htmlspecialchars(addslashes($demande['dmd_name']));
                        $mmb_ownername = htmlspecialchars(addslashes($demande['dmd_ownername'] ?: $demande['dmd_name']));
                        $mmb_coordinates = htmlspecialchars(addslashes($demande['dmd_coordinates']));
                        // $hashedPassword = hash('sha256', $generatedPassword);
                        
                        //get code from the cfg table:
                        $sql_select= "SELECT  cfg_code FROM t_configuration_cfg";
                        
                        $result_select = $mysqli->query($sql_select);
                        
                        if ($result_select == false) {
                            echo "Error: La requête a échoué<br>";
                            echo "Query: " . $sql_insert . "<br>";
                            echo "Errno: " . $mysqli->errno . "<br>";
                            echo "Error: " . $mysqli->error . "<br>";
                            exit();
                        } else {
                          $info = $result_select->fetch_assoc();
                          $code = $info['cfg_code'];


              

                        $sql_insert = "INSERT INTO t_members_mmb (mmb_name, mmb_ownername, mmb_coordinates) 
                                      VALUES ('$mmb_name', '$mmb_ownername', '$mmb_coordinates');";
                        
                        $result_insert = $mysqli->query($sql_insert);
                        
                        if ($result_insert == false) {
                            echo "Error: La requête a échoué<br>";
                            echo "Query: " . $sql_insert . "<br>";
                            echo "Errno: " . $mysqli->errno . "<br>";
                            echo "Error: " . $mysqli->error . "<br>";
                            exit();
                        } else {
                            $sql_delete = "DELETE FROM t_demandes_dmd WHERE dmd_id = $dmd_id;";
                            $mysqli->query($sql_delete);
                            
                            echo "<h4>Demande approuvée avec succès !</h4>";
                            echo "<p>Nom: " . htmlspecialchars($demande['dmd_name']) . "</p>";
                            echo "<p>Email: " . htmlspecialchars($demande['dmd_email']) . "</p>";
                            echo "<p>Téléphone: " . htmlspecialchars($demande['dmd_coordinates']) . "</p>";
                            // echo "<p>Mot de passe: " . htmlspecialchars($generatedPassword) . "</p>";
                            echo "<p>ATTENTION: Envoyez immédiatement un email à l'utilisateur avec le mot de passe suivant: " . $code . ".</p>";
                        }
                    }
                  }
                }




                // Handle deny action
                if (isset($_POST['deny'])) {
                    $dmd_id = intval($_POST['dmd_id']);
                    
                    $sql_delete = "DELETE FROM t_demandes_dmd WHERE dmd_id = $dmd_id;";
                    $result_delete = $mysqli->query($sql_delete);
                    
                    if ($result_delete == false) {
                        echo "Error: La requête a échoué<br>";
                        echo "Errno: " . $mysqli->errno . "<br>";
                        echo "Error: " . $mysqli->error . "<br>";
                    } else {
                        echo "<p style='color: green;'>Demande refusée et supprimée avec succès.</p>";
                    }
                }

                // Show demandes
                $sql_demandes = "SELECT * FROM t_demandes_dmd ORDER BY dmd_id DESC;";
                $result_demandes = $mysqli->query($sql_demandes);
                
                if ($result_demandes == false) {
                    echo "Error: La requête a échoué<br>";
                    echo "Errno: " . $mysqli->errno . "<br>";
                    echo "Error: " . $mysqli->error . "<br>";
                } else {
                    if ($result_demandes->num_rows > 0) {
                        echo "<hr>";
                        echo "&nbsp";
                        echo "<h4>Demandes d'adhésion en attente (" . $result_demandes->num_rows . ")</h4>";
                        echo "<table>";
                        echo "<tr>";
                        echo "<th>ID</th>";
                        echo "<th>Nom</th>";
                        echo "<th>Email</th>";
                        echo "<th>Message</th>";
                        echo "<th>Organisation</th>";
                        echo "<th>Téléphone</th>";
                        echo "<th>Actions</th>";
                        echo "</tr>";
                        
                        while ($demande = $result_demandes->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($demande['dmd_id']) . "</td>";
                            echo "<td>" . htmlspecialchars($demande['dmd_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($demande['dmd_email']) . "</td>";
                            echo "<td>" . htmlspecialchars($demande['dmd_paragraph']) . "</td>";
                            echo "<td>" . htmlspecialchars($demande['dmd_ownername']) . "</td>";
                            echo "<td>" . htmlspecialchars($demande['dmd_coordinates']) . "</td>";
                            echo "<td>";
                            echo "<form method='post' style='display:inline;'>";
                            echo "<input type='hidden' name='admin_username' value='" . htmlspecialchars($admin_username) . "'>";
                            echo "<input type='hidden' name='admin_password' value='" . htmlspecialchars($admin_password) . "'>";
                            echo "<input type='hidden' name='dmd_id' value='" . $demande['dmd_id'] . "'>";
                            echo "<button type='submit' name='approve' style='color:green'>Approuver</button>";
                            echo "</form>";
                            echo "<form method='post' style='display:inline;'>";
                            echo "<input type='hidden' name='admin_username' value='" . htmlspecialchars($admin_username) . "'>";
                            echo "<input type='hidden' name='admin_password' value='" . htmlspecialchars($admin_password) . "'>";
                            echo "<input type='hidden' name='dmd_id' value='" . $demande['dmd_id'] . "'>";
                            echo "<button type='submit' name='deny' style='color:green' onclick='return confirm(\"Êtes-vous sûr de vouloir refuser cette demande ?\");'>Refuser</button>";
                            echo "</form>";
                            echo "</td>";
                            echo "</tr>";
                        }
                        
                        echo "</table>";
                    } else {
                        echo "<p>Aucune demande d'adhésion en attente.</p>";
                    }
                }

                // Active accounts section
                echo "&nbsp";
                echo "<hr>";
                echo "&nbsp";
                echo "<h4>Comptes Actifs</h4>";
                
                $sql_active = "SELECT * FROM t_members_mmb ORDER BY mmb_name ASC;";
                $result_active = $mysqli->query($sql_active);
                
                if ($result_active == false) {
                    echo "Error: La requête a échoué<br>";
                    echo "Errno: " . $mysqli->errno . "<br>";
                    echo "Error: " . $mysqli->error . "<br>";
                } else {
                    if ($result_active->num_rows > 0) {
                        echo "<p>Nombre total de comptes actifs: <strong>" . $result_active->num_rows . "</strong></p>";
                        echo "<table>";
                        echo "<tr>";
                        echo "<th>Nom</th>";
                        echo "<th>Propriétaire</th>";
                        echo "<th>Coordonnées</th>";
                        echo "</tr>";
                        
                        while ($account = $result_active->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($account['mmb_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($account['mmb_ownername']) . "</td>";
                            echo "<td>" . htmlspecialchars($account['mmb_coordinates']) . "</td>";
                            echo "</tr>";
                        }
                        
                        echo "</table>";
                    } else {
                        echo "<p>Aucun compte actif.</p>";
                    }
                }
                

                break;
            }
        }

        if (!$authOK) {
            echo "Nom d'utilisateur ou mot de passe incorrect.";
        }
    }
    }

    $mysqli->close();
    ?>

  </div>

  <div id="footer">
    <p>© 2025 Système de Gestion Solaire</p>
    <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc())
      echo "
Nom du responsable: <b>" . $info['cfg_ownername'] . "</b><br>
Coordonnées: <b>" . $info['cfg_coordinates'] . "</b></p>";


    }
    
    $mysqli->close();
    
    ?>

  </div>


</body>

</html>