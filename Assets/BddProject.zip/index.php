<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Système de Gestion Solaire</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: url('https://images.unsplash.com/photo-1628953535333-a64a918181c0?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDEwfHx8ZW58MHx8fHx8&ixlib=rb-4.1.0&q=60&w=3000') center/cover no-repeat;
      min-height: 100vh;
      padding: 20px;
      display: flex;
      align-items: center;
      flex-direction: column;
      justify-content: center;
    }

    #header {
      width: 98%;
      height: auto;
      order: 1;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      border-radius: 2cap;
    }

    #navigation {
      width: 90%;
      height: auto;
      order: 2;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #contenu {
      width: 90%;
      height: auto;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      order: 3;
      background-color: #69e2ff;
      color: #495057;
      padding: 5%;
      text-align: center;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #footer {
      width: 98%;
      height: auto;
      order: 4;
      background-color: rgb(187, 241, 187);
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      color: #495057;
      text-align: center;
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    ul {
      margin-left: 20px;
      color: rgb(68, 66, 66);
      line-height: 1.8;
    }

    #navigation {
  width: 90%;
  height: auto;
  order: 2;
  background-color: #69e2ff;
  color: #495057;
  text-align: center;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
  padding: 15px;
  margin-top: 1%;
  border-radius: 2cap;
}

#navigation a {
  color: #495057;
  text-decoration: none;
  padding: 8px 12px;
  margin: 5px;
  display: inline-block;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 5px;
}

#navigation a:hover {
  background-color: rgba(255, 255, 255, 0.6);
}
#navigation a.active {
  background-color: rgba(0, 128, 0, 0.6); 
  color: white; 
}

#navigation a {
  color: #495057;
  text-decoration: none;
  padding: 8px 12px;
  margin: 5px;
  display: inline-block;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 5px;
}

#navigation a:hover {
  background-color: rgba(255, 255, 255, 0.6);
}
#navigation a.active {
  background-color: rgba(0, 128, 0, 0.6); 
  color: white; 
}


h3, h1 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}
 strong {
  color: #222;
}

 hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}

  </style>
</head>

<body>



  <div id="header">
  <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc()) {
        echo '<h1 style="display:flex; align-items:center; gap:10px; justify-content:center;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
            <b>'.$info['cfg_name'].'</b>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
        </h1>';
    }
    }
    
    $mysqli->close();
    ?>
    <p>Plateforme complète pour la gestion et le suivi de vos installations photovoltaïques</p>
  </div>




  <div id="navigation">
  <p>
  <a href="index.php" class="active">Présentation</a> 
  <a href="extraire.php">Extraire</a>
  <a href="installations.php">Installations</a> 
  <a href="ajout_installation.php">Ajouter installation</a> 
  <a href="join.php">Nous rejoindre</a>
</p>

  </div>

  <div id="contenu">
  <h3>À propos des panneaux solaires</h3>
<p>Les panneaux solaires convertissent l'énergie du soleil en électricité ou en chaleur. Ils sont essentiels pour produire une énergie propre et renouvelable. Ils sont fiables, durables et s’intègrent facilement sur les toits ou dans des installations au sol.</p>

<div style="max-width:800px; margin:0 auto;">
  <div style="margin-bottom:20px;;margin-top:30px;">
    <img src="https://www.choisir.com/medias/b7571dd4-toiture-photovoltaique.jpg" alt="Panneau solaire sur toit" style="width:100%; max-width:100%; height:auto; display:block; margin-bottom:10px;">
    <p><b>Panneaux photovoltaïques</b> : Convertissent la lumière du soleil en électricité. Ils sont idéaux pour l’autoconsommation et peuvent réduire significativement vos factures d’électricité.</p>
  </div>

  <div style="margin-bottom:20px;margin-top:30px;">
    <img src="https://www.solarquotes.com.au/wp-content/uploads/2018/09/solarsystem-1.jpg?auto=format&fit=crop&w=400&q=60" alt="Installation solaire" style="width:100%; max-width:100%; height:auto; display:block; margin-bottom:10px;">
    <p><b>Installation solaire complète</b> : Inclut panneaux, onduleurs et batteries. Cette configuration permet de stocker l’énergie produite et d’alimenter vos équipements même la nuit ou par temps nuageux.</p>
  </div>

  <div style="margin-bottom:20px;;margin-top:30px;">
    <img src="https://knowledge.wharton.upenn.edu/wp-content/uploads/2015/04/2015-04-19-IGEL-banner-art.jpg?auto=format&fit=crop&w=400&q=60" alt="Panneau solaire dans la nature" style="width:100%; max-width:100%; height:auto; display:block; margin-bottom:10px;">
    <p><b>Énergie renouvelable</b> : Utiliser l’énergie solaire contribue à la protection de l’environnement. Elle réduit les émissions de CO₂ et favorise une transition énergétique durable.</p>
  </div>
</div>

<p>Les panneaux solaires offrent de nombreux avantages : économies sur vos factures d’électricité, énergie durable, faible maintenance et indépendance énergétique. Investir dans le solaire, c’est préparer un avenir plus vert et plus économique.</p>

<hr>
    <h3>À propos du système</h3>
    <p >Notre plateforme de gestion d'installations solaires est conçue pour vous offrir une vue complète et
      détaillée de vos systèmes photovoltaïques. Que vous soyez un particulier, une entreprise ou un
      professionnel du secteur, notre solution vous accompagne dans la gestion quotidienne de vos
      installations.</p>
<hr>
      <h3>Fonctionnalités de la plateforme</h3>
      <p>Voici ce que notre plateforme est capable de faire :</p>
    <ul>
      <li>-Visualisation des données</li>
      <li>-Ajout d’installations</li>
      <li>-Centre d'information</li>
    </ul>

    <?php
$mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
if ($mysqli->connect_errno){
  echo "Error: Problème de connexion à la BDD<br>";
  echo "Errno: " . $mysqli->connect_errno . "<br>";
  echo "Error: " . $mysqli->connect_error . "<br>";
  exit();
}

if (!$mysqli->set_charset("utf8")) {
  printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
  exit();
}

mysqli_report(MYSQLI_REPORT_OFF); 
echo "Connexion BDD réussie !<br><br>";

$requeteBretagne = "
SELECT COUNT(*) AS nb_installations 
FROM t_installation_ins i
JOIN t_ville_vil USING (vil_id)
JOIN t_departement_dep USING (dep_id)
JOIN t_region_reg USING (reg_id)
WHERE reg_nom = 'Bretagne';";

$requeteFinistere = "
SELECT COUNT(*) AS nb_installations 
FROM t_installation_ins i
JOIN t_ville_vil USING (vil_id)
JOIN t_departement_dep USING (dep_id)
WHERE dep_nom = 'Finistère';";

$requeteMorbihan = "
SELECT COUNT(*) AS nb_installations 
FROM t_installation_ins i
JOIN t_ville_vil USING (vil_id)
JOIN t_departement_dep USING (dep_id)
WHERE dep_nom = 'Morbihan';"; 

$requeteArmor = "
SELECT COUNT(*) AS nb_installations 
FROM t_installation_ins i
JOIN t_ville_vil USING (vil_id)
JOIN t_departement_dep USING (dep_id)
WHERE dep_nom = 'Côtes-d\'Armor';";

$requeteVilaine = "
SELECT COUNT(*) AS nb_installations 
FROM t_installation_ins i
JOIN t_ville_vil USING (vil_id)
JOIN t_departement_dep USING (dep_id)
WHERE dep_nom = 'Ille-et-Vilaine';";

$queries = [
  'Bretagne'  => $requeteBretagne,
  'Finistère' => $requeteFinistere,
  'Morbihan'  => $requeteMorbihan,
  'Côtes-d\'Armor' => $requeteArmor,
  'Ille-et-Vilaine' => $requeteVilaine
];
echo "<h3>Quelques statistiques</h3>
<p>Voici un aperçu de nos installations par région :</p>";  

foreach ($queries as $region => $query) {
  $result = $mysqli->query($query);
  
  if ($result === false) {
    echo "Erreur sur $region : " . $mysqli->error . "<br>";
  } else {

    $row = $result->fetch_assoc();
    $count = $row['nb_installations'] ?? 0;
    echo "<strong>$region :</strong> $count installations<br>";
    $result->free();
  }
}


$mysqli->close();

?>


  </div>

  <div id="footer">
    <p>© 2025 Système de Gestion Solaire</p>
    <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc())
      echo "
Nom du responsable: <b>" . $info['cfg_ownername'] . "</b><br>
Coordonnées: <b>" . $info['cfg_coordinates'] . "</b></p>";


    }
    
    $mysqli->close();
    
    ?>

  </div>

</body>

</html>