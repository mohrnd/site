<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Système de Gestion Solaire</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: url('https://images.unsplash.com/photo-1628953535333-a64a918181c0?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDEwfHx8ZW58MHx8fHx8&ixlib=rb-4.1.0&q=60&w=3000') center/cover no-repeat;
      min-height: 100vh;
      padding: 20px;
      display: flex;
      align-items: center;
      flex-direction: column;
      justify-content: center;
    }

    #header {
      width: 98%;
      height: auto;
      order: 1;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      border-radius: 2cap;
    }

    #navigation {
      width: 90%;
      height: auto;
      order: 2;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #contenu {
      width: 90%;
      height: auto;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      order: 3;
      background-color: #69e2ff;
      color: #495057;
      padding: 5%;
      text-align: center;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #footer {
      width: 98%;
      height: auto;
      order: 4;
      background-color: rgb(187, 241, 187);
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      color: #495057;
      text-align: center;
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    ul {
      margin-left: 20px;
      color: rgb(68, 66, 66);
      line-height: 1.8;
    }
    form p {
    margin: 15px 0;       
}

form input, form select {
    padding: 6px;          
    margin-top: 5px;      
}
#navigation a {
  color: #495057;
  text-decoration: none;
  padding: 8px 12px;
  margin: 5px;
  display: inline-block;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 5px;
}

#navigation a:hover {
  background-color: rgba(255, 255, 255, 0.6);
}
#navigation a.active {
  background-color: rgba(0, 128, 0, 0.6); 
  color: white; 
}
#contenu h3 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


#contenu p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

#contenu ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}

#contenu strong {
  color: #222;
}

#contenu hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}

h3, h1 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}
 strong {
  color: #222;
}

 hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}

  </style>
</head>

<body>


<div id="header">
  <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc()) {
        echo '<h1 style="display:flex; align-items:center; gap:10px; justify-content:center;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
            <b>'.$info['cfg_name'].'</b>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
        </h1>';
    }
    }
    
    $mysqli->close();
    ?>
    <p>Plateforme complète pour la gestion et le suivi de vos installations photovoltaïques</p>
  </div>

  <div id="navigation">
  <p>
  <a href="index.php">Présentation</a> 
  <a href="extraire.php">Extraire</a>
  <a href="installations.php">Installations</a> 
  <a href="ajout_installation.php">Ajouter installation</a> 
  <a href="join.php" class="active">Nous rejoindre</a>
</p>
  </div>

  <div id="contenu">
    <h1>Demande d'adhésion</h1>
    <p>Soumettez votre demande pour devenir utilisateur</p>
    <form action="join_action.php" method="post">
    <p>Nom: <input type="text" name="dmd_name" required></p>
    <p>Email: <input type="email" name="dmd_email" required></p>
    <p>Message: <textarea name="dmd_paragraph" style="width: 200px; height: 200px;"></textarea></p>
    <p>Organisation/Propriétaire: <input type="text" name="dmd_ownername"></p>
    <p>Numéro de téléphone : <input type="tel" name="dmd_coordinates" required /></p>
    <p><input type="submit" value="Envoyer la demande"></p>
</form>

<?php
$mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
if ($mysqli->connect_errno){
  echo "Error: Problème de connexion à la BDD<br>";
  echo "Errno: " . $mysqli->connect_errno . "<br>";
  echo "Error: " . $mysqli->connect_error . "<br>";
  exit();
}

if (!$mysqli->set_charset("utf8")) {
  printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
  exit();
}

mysqli_report(MYSQLI_REPORT_OFF); 
// echo "Connexion BDD réussie !<br><br>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dmd_name = htmlspecialchars(addslashes($_POST['dmd_name']));
    $dmd_email = htmlspecialchars(addslashes($_POST['dmd_email']));
    $dmd_paragraph = htmlspecialchars(addslashes($_POST['dmd_paragraph']));
    $dmd_ownername = htmlspecialchars(addslashes($_POST['dmd_ownername']));
    $dmd_coordinates = htmlspecialchars(addslashes($_POST['dmd_coordinates'])); // phone number

    if (empty($dmd_name) || empty($dmd_email) || empty($dmd_coordinates)) {
        echo 'Veuillez remplir les formulaires obligatoires !!!';
    } else {
        // Check if email already exists in t_demandes_dmd
        $sql_check_demandes = "SELECT dmd_email FROM t_demandes_dmd WHERE dmd_email = '$dmd_email';";
        $result_check_demandes = $mysqli->query($sql_check_demandes);
        
        // Check if email already exists in t_configuration_cfg (active users)
        $sql_check_config = "SELECT mmb_coordinates FROM t_members_mmb WHERE mmb_coordinates = '$dmd_email';";
        $result_check_members = $mysqli->query($sql_check_config);
        
        if ($result_check_demandes == false || $result_check_members == false) {
            echo "Error: La requête a échoué<br>";
            echo "Errno: " . $mysqli->errno . "<br>";
            echo "Error: " . $mysqli->error . "<br>";
            exit();
        }
        
        if ($result_check_demandes->num_rows > 0) {
            echo "Cet email a déjà été utilisé pour une demande d'adhésion en attente.";
        } else if ($result_check_members->num_rows > 0) {
            echo "Cet email est déjà associé à un compte actif.";
        } else {
            // Email doesn't exist, proceed with insertion
            $sql_insert = "INSERT INTO t_demandes_dmd 
            (dmd_id, dmd_name, dmd_email, dmd_paragraph, dmd_ownername, dmd_coordinates) 
            VALUES (NULL, '$dmd_name', '$dmd_email', '$dmd_paragraph', '$dmd_ownername', '$dmd_coordinates');";

            $res = $mysqli->query($sql_insert);
            if ($res == false) {
                echo "Error: La requête a échoué \n";
                echo "Query: " . $sql_insert . "\n";
                echo "Errno: " . $mysqli->errno . "\n";
                echo "Error: " . $mysqli->error . "\n";
                exit;
            } else {
                echo "Demande envoyée avec succès !";
            }
        }
    }
}

$mysqli->close();
?>


  </div>


  <div id="footer">
    <p>© 2025 Système de Gestion Solaire</p>
    <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc())
      echo "
Nom du responsable: <b>" . $info['cfg_ownername'] . "</b><br>
Coordonnées: <b>" . $info['cfg_coordinates'] . "</b></p>";


    }
    
    $mysqli->close();
    
    ?>

  </div>

</body>
</html>