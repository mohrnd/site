<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Détails de l'installation - Système de Gestion Solaire</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: url('https://images.unsplash.com/photo-1628953535333-a64a918181c0?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDEwfHx8ZW58MHx8fHx8&ixlib=rb-4.1.0&q=60&w=3000') center/cover no-repeat;
      min-height: 100vh;
      padding: 20px;
      display: flex;
      align-items: center;
      flex-direction: column;
      justify-content: center;
    }

    #header {
      width: 98%;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      border-radius: 2cap;
    }

    #navigation {
      width: 90%;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #contenu {
      width: 90%;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      background-color: #69e2ff;
      color: #495057;
      padding: 3%;
      text-align: center;
      margin-top: 1%;
      border-radius: 2cap;
      overflow-x: auto;
    }

    #footer {
      width: 98%;
      background-color: rgb(187, 241, 187);
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      color: #495057;
      text-align: center;
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #info-containers {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 15px;
      margin: 20px 0;
    }

    #install-date, #location, #department, #region, #coordinates, 
    #constructor, #panel-model, #nb-panels, #power, #surface, #slope {
      background: rgba(255, 255, 255, 0.4);
      padding: 15px;
      border-radius: 10px;
      text-align: left;
    }

    #install-date h4, #location h4, #department h4, #region h4, #coordinates h4,
    #constructor h4, #panel-model h4, #nb-panels h4, #power h4, #surface h4, #slope h4 {
      color: #2c3e50;
      margin-bottom: 8px;
      font-size: 14px;
    }

    #install-date p, #location p, #department p, #region p, #coordinates p,
    #constructor p, #panel-model p, #nb-panels p, #power p, #surface p, #slope p {
      color: #495057;
      font-size: 16px;
      font-weight: bold;
    }

    #image-container {
      margin: 20px 0;
    }

    #navigation a {
      color: #495057;
      text-decoration: none;
      padding: 8px 12px;
      margin: 5px;
      display: inline-block;
      background-color: rgba(255, 255, 255, 0.3);
      border-radius: 5px;
    }

    #navigation a:hover {
      background-color: rgba(255, 255, 255, 0.6);
    }

    #navigation a.active {
      background-color: rgba(0, 128, 0, 0.6);
      color: white;
    }
    #contenu h3 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


#contenu p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

#contenu ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}

#contenu strong {
  color: #222;
}

#contenu hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}
h3, h1 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}
 strong {
  color: #222;
}

 hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}

  </style>
</head>

<body>

<div id="header">
  <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc()) {
        echo '<h1 style="display:flex; align-items:center; gap:10px; justify-content:center;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
            <b>'.$info['cfg_name'].'</b>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
            </svg>
        </h1>';
    }
    }
    
    $mysqli->close();
    ?>
    <p>Plateforme complète pour la gestion et le suivi de vos installations photovoltaïques</p>
  </div>


  <div id="navigation">
    <p>
      <a href="index.php">Présentation</a>
      <a href="extraire.php">Extraire</a>
      <a href="installations.php" class="active">Installations</a>
      <a href="ajout_installation.php">Ajouter installation</a>
      <a href="join.php">Nous rejoindre</a>
    </p>
  </div>

  <div id="contenu">
    <?php
    $mysqli = new mysqli('localhost', 'e22406557', 'PAXwLgRt', 'e22406557_db2');
    if ($mysqli->connect_errno) {
      echo "Error: Problème de connexion à la BDD<br>";
      exit();
    }

    $mysqli->set_charset("utf8");

    if (isset($_GET['ins_id'])) {
      $ins_id = intval($_GET['ins_id']);

      $sql = "SELECT 
                i.ins_id,
                i.ins_mois,
                i.ins_annee,
                i.ins_nb_panneaux,
                i.ins_latitude,
                i.ins_longitude,
                v.vil_nom,
                v.vil_cp,
                d.dep_nom,
                r.reg_nom,
                p.pan_ref,
                c.cst_nom,
                m.mes_puissance,
                m.mes_surface,
                m.mes_pente
              FROM t_installation_ins i
              JOIN t_ville_vil v USING (vil_id)
              JOIN t_departement_dep d USING (dep_id)
              JOIN t_region_reg r USING (reg_id)
              JOIN t_panneau_pan p USING (pan_id)
              JOIN t_constructeur_cst c USING (cst_id)
              JOIN t_mesure_mes m USING (ins_id)
              WHERE i.ins_id = $ins_id;";

      $result = $mysqli->query($sql);

      if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
        ?>

        <h2>Installation #<?php echo $data['ins_id']; ?></h2>

        <div id="info-containers">

          <div id="install-date">
            <h4>Date d'installation</h4>
            <p><?php echo $data['ins_mois']; ?>/<?php echo $data['ins_annee']; ?></p>
          </div>

          <div id="nb-panels">
            <h4>Nombre de panneaux</h4>
            <p><?php echo $data['ins_nb_panneaux']; ?></p>
          </div>

          <div id="location">
            <h4>Localisation</h4>
            <p><?php echo $data['vil_nom']; ?> (<?php echo $data['vil_cp']; ?>)</p>
          </div>

          <div id="department">
            <h4>Département</h4>
            <p><?php echo $data['dep_nom']; ?></p>
          </div>

          <div id="region">
            <h4>Région</h4>
            <p><?php echo $data['reg_nom']; ?></p>
          </div>

          <div id="coordinates">
            <h4>Coordonnées GPS</h4>
            <p>Lat: <?php echo $data['ins_latitude']; ?>, Long: <?php echo $data['ins_longitude']; ?></p>
          </div>

          <div id="constructor">
            <h4>Constructeur</h4>
            <p><?php echo $data['cst_nom']; ?></p>
          </div>

          <div id="panel-model">
            <h4>Modèle de panneau</h4>
            <p><?php echo $data['pan_ref']; ?></p>
          </div>

          <div id="power">
            <h4>Puissance</h4>
            <p><?php echo $data['mes_puissance']; ?> W</p>
          </div>

          <div id="surface">
            <h4>Surface</h4>
            <p><?php echo $data['mes_surface']; ?> m²</p>
          </div>

          <div id="slope">
            <h4>Pente</h4>
            <p><?php echo $data['mes_pente']; ?>°</p>
          </div>

        </div>

        <div id="image-container">
          <?php
          $img_sql = "SELECT img_blob FROM t_images_img WHERE img_installid = $ins_id LIMIT 1;";
          $img_result = $mysqli->query($img_sql);

          if ($img_result && $img_result->num_rows > 0) {
            $img_row = $img_result->fetch_assoc();
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime_type = $finfo->buffer($img_row['img_blob']);
            $base64_image = base64_encode($img_row['img_blob']);
            ?>
            
            <h3>Image de l'installation</h3>
            <img src="data:<?php echo $mime_type; ?>;base64,<?php echo $base64_image; ?>" alt="Installation solaire" style="max-width: 100%;height: auto;margin: 20px 0;border-radius: 10px;">
            
          <?php } else { ?>
            
            <div>
              <h3>Aucune image disponible</h3>
              <p>Aucune image n'a été téléchargée pour cette installation.</p>
            </div>
            
          <?php } ?>
        </div>

        <?php
      } else {
        echo "<p>Installation non trouvée.</p>";
      }
    } else {
      echo "<p>ID d'installation manquant.</p>";
    }

    $mysqli->close();
    ?>
  </div>

  <div id="footer">
    <p>© 2025 Système de Gestion Solaire</p>
    <?php 
    $mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
    if ($mysqli->connect_errno){
      echo "Error: Problème de connexion à la BDD<br>";
      echo "Errno: " . $mysqli->connect_errno . "<br>";
      echo "Error: " . $mysqli->connect_error . "<br>";
      exit();
    }
    
    if (!$mysqli->set_charset("utf8")) {
      printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
      exit();
    }
    
    mysqli_report(MYSQLI_REPORT_OFF); 
    // echo "Connexion BDD réussie !<br><br>";
    
    $requetecfg = "SELECT * FROM `t_configuration_cfg`";
    $result = $mysqli->query($requetecfg);
    if ($result === false) {
      echo "Error: La requête a echoué \n";
      echo "Errno: " . $mysqli->errno . "\n";
      echo "Error: " . $mysqli->error . "\n";
      exit();
    }
    else {
      while ($info = $result->fetch_assoc())
      echo "
Nom du responsable: <b>" . $info['cfg_ownername'] . "</b><br>
Coordonnées: <b>" . $info['cfg_coordinates'] . "</b></p>";


    }
    
    $mysqli->close();
    
    ?>

  </div>

</body>

</html>