<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Système de Gestion Solaire</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: url('https://images.unsplash.com/photo-1628953535333-a64a918181c0?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDEwfHx8ZW58MHx8fHx8&ixlib=rb-4.1.0&q=60&w=3000') center/cover no-repeat;
      min-height: 100vh;
      padding: 20px;
      display: flex;
      align-items: center;
      flex-direction: column;
      justify-content: center;
    }

    #header {
      width: 98%;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      border-radius: 2cap;
    }

    #navigation {
      width: 90%;
      background-color: #69e2ff;
      color: #495057;
      text-align: center;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    #contenu {
      width: 90%;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      background-color: #69e2ff;
      color: #495057;
      padding: 3%;
      text-align: center;
      margin-top: 1%;
      border-radius: 2cap;
      overflow-x: auto;
    }

    #footer {
      width: 98%;
      background-color: rgb(187, 241, 187);
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      color: #495057;
      text-align: center;
      padding: 10px;
      margin-top: 1%;
      border-radius: 2cap;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: center;
    }

    th {
      background-color: #e0f7fa;
      font-weight: bold;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    #navigation a {
  color: #495057;
  text-decoration: none;
  padding: 8px 12px;
  margin: 5px;
  display: inline-block;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 5px;
}

#navigation a:hover {
  background-color: rgba(255, 255, 255, 0.6);
}
#navigation a.active {
  background-color: rgba(0, 128, 0, 0.6); 
  color: white; 
}
form p {
    margin: 15px 0;       
}

form input, form select {
    padding: 6px;          
    margin-top: 5px;      
}
#contenu h3 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


#contenu p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

#contenu ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}

#contenu strong {
  color: #222;
}

#contenu hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}
h3, h1 {
  font-size: 1.8em;
  margin-top: 30px;
  margin-bottom: 15px;
  color: #333;
}


p {
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.6;
  color: #444;
}

ul {
  margin-left: 0;
  padding-left: 0;
  list-style: none;
  line-height: 1.8;
}
 strong {
  color: #222;
}

 hr {
  border: 0;
  border-top: 1px solid #aaa;
  margin: 30px 0;
}
label {
  margin: 8px 15px;
}

  </style>
</head>

<body>
<?php 
// Database connection
$mysqli = new mysqli('localhost','e22406557','PAXwLgRt','e22406557_db2');
if ($mysqli->connect_errno) {
  echo "Error: Problème de connexion à la BDD<br>";
  exit();
}
$mysqli->set_charset("utf8");
mysqli_report(MYSQLI_REPORT_OFF); 
?>

<div id="header">
  <?php 
  $result = $mysqli->query("SELECT * FROM t_configuration_cfg");
  if ($result) {
    $info = $result->fetch_assoc();
    echo '<h1 style="display:flex; align-items:center; gap:10px; justify-content:center;">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
            <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
        </svg>
        <b>'.$info['cfg_name'].'</b>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="yellow" class="bi bi-sun" viewBox="0 0 16 16">
            <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6m0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8M8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0m0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13m8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5M3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8m10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0m-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0m9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707M4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708"/>
        </svg>
    </h1>';
  }
  ?>
  <p>Plateforme complète pour la gestion et le suivi de vos installations photovoltaïques</p>
</div>

<div id="navigation">
  <p>
    <a href="index.php">Présentation</a>
    <a href="extraire.php" class="active">Extraire</a>
    <a href="installations.php">Installations</a>
    <a href="ajout_installation.php">Ajouter installation</a>
    <a href="join.php">Nous rejoindre</a>
  </p>
</div>

<div id="contenu">
  <h3>Extraire les données d'installations</h3>
  <br><br>

  <form action="extraire_action.php" method="post">
    <hr><br>
    <h4>Sélection des colonnes à afficher</h4><br>

    <div style="display:flex;flex-wrap:wrap;justify-content:center;align-items:center;">
      <label><input type="checkbox" name="cols[]" value="ins_mois" checked> Mois</label>
      <label><input type="checkbox" name="cols[]" value="ins_annee" checked> Année</label>
      <label><input type="checkbox" name="cols[]" value="ins_nb_panneaux" checked> Nb Panneaux</label>
      <label><input type="checkbox" name="cols[]" value="vil_nom" checked> Ville</label>
      <label><input type="checkbox" name="cols[]" value="vil_cp" checked> Code Postal</label>
      <label><input type="checkbox" name="cols[]" value="dep_nom" checked> Département</label>
      <label><input type="checkbox" name="cols[]" value="reg_nom" checked> Région</label>
      <label><input type="checkbox" name="cols[]" value="ins_latitude" checked> Latitude</label>
      <label><input type="checkbox" name="cols[]" value="ins_longitude" checked> Longitude</label>
      <label><input type="checkbox" name="cols[]" value="cst_nom" checked> Constructeur</label>
      <label><input type="checkbox" name="cols[]" value="pan_ref" checked> Modèle Panneau</label>
      <label><input type="checkbox" name="cols[]" value="mes_puissance" checked> Puissance (W)</label>
      <label><input type="checkbox" name="cols[]" value="mes_surface" checked> Surface (m²)</label>
      <label><input type="checkbox" name="cols[]" value="mes_pente" checked> Pente (°)</label>
      <label><input type="checkbox" name="cols[]" value="image" checked> Details</label>
    </div>
    <br><hr><br>
    
    <h4>Filtres de recherche</h4><br>

    <p>Mois d'installation:
      <select name="mois">
        <option value="">-- Tous les mois --</option>
        <option value="01">January</option>
        <option value="02">February</option>
        <option value="03">March</option>
        <option value="04">April</option>
        <option value="05">May</option>
        <option value="06">June</option>
        <option value="07">July</option>
        <option value="08">August</option>
        <option value="09">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>
      </select>
    </p>

    <p>Année d'installation:
      <select name="annee">
        <option value="">-- Toutes les années --</option>
        <?php for ($y = 2000; $y <= 2025; $y++) echo "<option value='$y'>$y</option>"; ?>
      </select>
    </p>

    <p>Nombre de panneaux:
      <div>
        Min: <input type="number" name="nb_panneaux_min" placeholder="Min">
        Max: <input type="number" name="nb_panneaux_max" placeholder="Max">
      </div>
    </p>

    <p>Région:
      <select name="region">
        <option value="">-- Toutes les régions --</option>
        <?php 
        $result = $mysqli->query("SELECT reg_id, reg_nom FROM t_region_reg ORDER BY reg_nom");
        while ($r = $result->fetch_assoc()) {
          echo "<option value='{$r['reg_id']}'>{$r['reg_nom']}</option>";
        }
        ?>
      </select>
    </p>

    <p>Département:
      <select name="departement">
        <option value="">-- Tous les départements --</option>
        <?php 
        $result = $mysqli->query("SELECT dep_id, dep_nom FROM t_departement_dep ORDER BY dep_nom");
        while ($d = $result->fetch_assoc()) {
          echo "<option value='{$d['dep_id']}'>{$d['dep_id']} - {$d['dep_nom']}</option>";
        }
        ?>
      </select>
    </p>

    <p>Ville:
      <select name="ville">
        <option value="">-- Toutes les villes --</option>
        <?php 
        $result = $mysqli->query("SELECT DISTINCT vil_nom, dep_id FROM t_ville_vil ORDER BY dep_id");
        while ($v = $result->fetch_assoc()) {
          echo "<option value='{$v['vil_nom']}'>{$v['vil_nom']} ({$v['dep_id']})</option>";
        }
        ?>
      </select>
    </p>

    <p>Latitude:
      <div>
        Min: <input type="number" step="0.000001" name="lat_min" placeholder="Min">
        Max: <input type="number" step="0.000001" name="lat_max" placeholder="Max">
      </div>
    </p>

    <p>Longitude:
      <div>
        Min: <input type="number" step="0.000001" name="long_min" placeholder="Min">
        Max: <input type="number" step="0.000001" name="long_max" placeholder="Max">
      </div>
    </p>

    <p>Constructeur:
      <select name="constructeur">
        <option value="">-- Tous les constructeurs --</option>
        <?php 
        $result = $mysqli->query("SELECT cst_id, cst_nom FROM t_constructeur_cst ORDER BY cst_nom");
        while ($c = $result->fetch_assoc()) {
          echo "<option value='{$c['cst_id']}'>{$c['cst_nom']}</option>";
        }
        ?>
      </select>
    </p>

    <p>Modèle de panneau:
      <select name="panneau">
        <option value="">-- Tous les modèles --</option>
        <?php 
        $result = $mysqli->query("SELECT p.pan_id, p.pan_ref, c.cst_nom FROM t_panneau_pan p JOIN t_constructeur_cst c USING (cst_id) ORDER BY c.cst_nom, p.pan_ref");
        while ($p = $result->fetch_assoc()) {
          echo "<option value='{$p['pan_id']}'>{$p['cst_nom']} - {$p['pan_ref']}</option>";
        }
        ?>
      </select>
    </p>

    <p>Puissance (W):
      <div>
        Min: <input type="number" name="puissance_min" placeholder="Min">
        Max: <input type="number" name="puissance_max" placeholder="Max">
      </div>
    </p>

    <p>Surface (m²):
      <div>
        Min: <input type="number" step="0.01" name="surface_min" placeholder="Min">
        Max: <input type="number" step="0.01" name="surface_max" placeholder="Max">
      </div>
    </p>

    <p>Pente (°):
      <div>
        Min: <input type="number" step="0.1" name="pente_min" placeholder="Min">
        Max: <input type="number" step="0.1" name="pente_max" placeholder="Max">
      </div>
    </p>

    <p>
      <input type="submit" value="Extraire les données">
      <input type="button" value="Réinitialiser" onclick="window.location.href='extraire.php'">
    </p>
  </form>

  <?php
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cols = $_POST['cols'] ?? [];
    
    // Build WHERE clause
    $where = "WHERE 1=1";
    if ($_POST['mois']) $where .= " AND i.ins_mois = '{$_POST['mois']}'";
    if ($_POST['annee']) $where .= " AND i.ins_annee = {$_POST['annee']}";
    if ($_POST['nb_panneaux_min']) $where .= " AND i.ins_nb_panneaux >= {$_POST['nb_panneaux_min']}";
    if ($_POST['nb_panneaux_max']) $where .= " AND i.ins_nb_panneaux <= {$_POST['nb_panneaux_max']}";
    if ($_POST['region']) $where .= " AND r.reg_id = {$_POST['region']}";
    if ($_POST['departement']) $where .= " AND d.dep_id = '{$_POST['departement']}'";
    if ($_POST['ville']) $where .= " AND v.vil_nom = '{$_POST['ville']}'";
    if ($_POST['lat_min']) $where .= " AND i.ins_latitude >= {$_POST['lat_min']}";
    if ($_POST['lat_max']) $where .= " AND i.ins_latitude <= {$_POST['lat_max']}";
    if ($_POST['long_min']) $where .= " AND i.ins_longitude >= {$_POST['long_min']}";
    if ($_POST['long_max']) $where .= " AND i.ins_longitude <= {$_POST['long_max']}";
    if ($_POST['constructeur']) $where .= " AND c.cst_id = {$_POST['constructeur']}";
    if ($_POST['panneau']) $where .= " AND p.pan_id = {$_POST['panneau']}";
    if ($_POST['puissance_min']) $where .= " AND m.mes_puissance >= {$_POST['puissance_min']}";
    if ($_POST['puissance_max']) $where .= " AND m.mes_puissance <= {$_POST['puissance_max']}";
    if ($_POST['surface_min']) $where .= " AND m.mes_surface >= {$_POST['surface_min']}";
    if ($_POST['surface_max']) $where .= " AND m.mes_surface <= {$_POST['surface_max']}";
    if ($_POST['pente_min']) $where .= " AND m.mes_pente >= {$_POST['pente_min']}";
    if ($_POST['pente_max']) $where .= " AND m.mes_pente <= {$_POST['pente_max']}";

    $sql = "SELECT i.ins_id, i.ins_mois, i.ins_annee, i.ins_nb_panneaux, i.ins_latitude, i.ins_longitude,
                   v.vil_nom, v.vil_cp, d.dep_nom, r.reg_nom, c.cst_nom, p.pan_ref,
                   m.mes_puissance, m.mes_surface, m.mes_pente
            FROM t_installation_ins i
            JOIN t_mesure_mes m USING (ins_id)
            JOIN t_ville_vil v USING (vil_id)
            JOIN t_departement_dep d USING (dep_id)
            JOIN t_region_reg r USING (reg_id)
            JOIN t_panneau_pan p USING (pan_id)
            JOIN t_constructeur_cst c USING (cst_id)
            $where
            ORDER BY i.ins_id DESC";

    $result = $mysqli->query($sql);

    if (!$result) {
      echo "<p style='color: red;'>Erreur : " . $mysqli->error . "</p>";
    } else {
      echo "<p>Nombre d'installations trouvées : <strong>" . $result->num_rows . "</strong></p>";

      if ($result->num_rows > 0) {
        echo "<table><thead><tr>";
        echo "<th>Id</th>";
        if (in_array('ins_mois', $cols)) echo "<th>Mois</th>";
        if (in_array('ins_annee', $cols)) echo "<th>Année</th>";
        if (in_array('ins_nb_panneaux', $cols)) echo "<th>Nb Panneaux</th>";
        if (in_array('vil_nom', $cols)) echo "<th>Ville</th>";
        if (in_array('vil_cp', $cols)) echo "<th>Code Postal</th>";
        if (in_array('dep_nom', $cols)) echo "<th>Département</th>";
        if (in_array('reg_nom', $cols)) echo "<th>Région</th>";
        if (in_array('ins_latitude', $cols)) echo "<th>Latitude</th>";
        if (in_array('ins_longitude', $cols)) echo "<th>Longitude</th>";
        if (in_array('cst_nom', $cols)) echo "<th>Constructeur</th>";
        if (in_array('pan_ref', $cols)) echo "<th>Modèle</th>";
        if (in_array('mes_puissance', $cols)) echo "<th>Puissance (W)</th>";
        if (in_array('mes_surface', $cols)) echo "<th>Surface (m²)</th>";
        if (in_array('mes_pente', $cols)) echo "<th>Pente (°)</th>";
        if (in_array('image', $cols)) echo "<th>Details</th>";
        
        echo "</tr></thead><tbody>";

        while ($row = $result->fetch_assoc()) {
          echo "<tr>";
          echo "<td>{$row['ins_id']}</td>";
          if (in_array('ins_mois', $cols)) echo "<td>{$row['ins_mois']}</td>";
          if (in_array('ins_annee', $cols)) echo "<td>{$row['ins_annee']}</td>";
          if (in_array('ins_nb_panneaux', $cols)) echo "<td>{$row['ins_nb_panneaux']}</td>";
          if (in_array('vil_nom', $cols)) echo "<td>{$row['vil_nom']}</td>";
          if (in_array('vil_cp', $cols)) echo "<td>{$row['vil_cp']}</td>";
          if (in_array('dep_nom', $cols)) echo "<td>{$row['dep_nom']}</td>";
          if (in_array('reg_nom', $cols)) echo "<td>{$row['reg_nom']}</td>";
          if (in_array('ins_latitude', $cols)) echo "<td>{$row['ins_latitude']}</td>";
          if (in_array('ins_longitude', $cols)) echo "<td>{$row['ins_longitude']}</td>";
          if (in_array('cst_nom', $cols)) echo "<td>{$row['cst_nom']}</td>";
          if (in_array('pan_ref', $cols)) echo "<td>{$row['pan_ref']}</td>";
          if (in_array('mes_puissance', $cols)) echo "<td>{$row['mes_puissance']}</td>";
          if (in_array('mes_surface', $cols)) echo "<td>{$row['mes_surface']}</td>";
          if (in_array('mes_pente', $cols)) echo "<td>{$row['mes_pente']}</td>";
          
          if (in_array('image', $cols)) {
            $ins_id = $row['ins_id'];
            $img_check = $mysqli->query("SELECT img_id FROM t_images_img WHERE img_installid = $ins_id LIMIT 1;");
            
            echo "<td>";
              echo "<a href='display_image.php?ins_id=$ins_id' target='_blank'>Voir</a>";
            echo "</td>";
            
            echo "</tr>";
          }
          
          echo "</tr>";
        }

        echo "</tbody></table>";
      } else {
        echo "<p>Aucune installation ne correspond à vos critères.</p>";
      }
    }
  }
  ?>
</div>

<div id="footer">
  <p>© 2025 Système de Gestion Solaire</p>
  <?php 
  $result = $mysqli->query("SELECT * FROM t_configuration_cfg");
  if ($result) {
    $info = $result->fetch_assoc();
    echo "Nom du responsable: <b>{$info['cfg_ownername']}</b><br>Coordonnées: <b>{$info['cfg_coordinates']}</b>";
  }
  $mysqli->close();
  ?>
</div>

</body>
</html>