CREATE TABLE `t_demandes_dmd` (
    `dmd_id` INT NOT NULL AUTO_INCREMENT,
    `dmd_name` VARCHAR(100) NOT NULL,
    `dmd_email` VARCHAR(150) NOT NULL,
    `dmd_paragraph` TEXT,
    `dmd_ownername` VARCHAR(100),
    `dmd_coordinates` VARCHAR(100),
    PRIMARY KEY (`dmd_id`)
);

CREATE TABLE `t_admin_adm` (
    `adm_id` INT NOT NULL AUTO_INCREMENT,
    `adm_username` VARCHAR(50) NOT NULL UNIQUE,
    `adm_password` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`adm_id`)
);

-- Delete and edit the cg table 

DROP TABLE IF EXISTS `t_configuration_cfg`;

CREATE TABLE `t_configuration_cfg` (
  `cfg_id` INT NOT NULL AUTO_INCREMENT,
  `cfg_name` VARCHAR(50) DEFAULT NULL,
  `cfg_ownername` VARCHAR(50) DEFAULT NULL,
  `cfg_coordinates` VARCHAR(50) DEFAULT NULL,
  `cfg_code` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`cfg_id`)
);

INSERT INTO t_configuration_cfg (
    cfg_name,
    cfg_ownername,
    cfg_coordinates,
    cfg_code
) VALUES (
    'SolarHess',
    'Mohend',
    '+33 7777 99 23',
    '28ca99c9e778ddab'
);


CREATE TABLE `t_members_mmb` (
  `mmb_id` INT NOT NULL AUTO_INCREMENT,
  `mmb_name` VARCHAR(50) DEFAULT NULL,
  `mmb_ownername` VARCHAR(50) DEFAULT NULL,
  `mmb_coordinates` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`mmb_id`)
);

CREATE TABLE `t_images_img` (
    `img_id` INT NOT NULL AUTO_INCREMENT,
    `img_installid` INT NOT NULL,
    `img_blob` LONGBLOB NOT NULL,
    PRIMARY KEY (`img_id`),
    FOREIGN KEY (`img_installid`) REFERENCES `t_installation_ins`(`ins_id`)
);
